import os
import pandas as pd

# Define the paths
main_dir = os.path.expanduser("~/Desktop/DataPaper")
output_dir = os.path.expanduser("~/Desktop/HR")

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Loop through each user directory (user_1, user_2, ..., user_22)
for user_num in range(1, 23):
    user_dir = f"user_{user_num}"
    user_path = os.path.join(main_dir, user_dir)
    
    if os.path.isdir(user_path):  # Ensure it is a directory
        actigraph_file = os.path.join(user_path, "Actigraph.csv")
        
        if os.path.isfile(actigraph_file):  # Ensure the file exists
            # Load the Actigraph.csv file
            df = pd.read_csv(actigraph_file)
            
            # Convert 'time' to datetime format to easily extract the hour
            df['time'] = pd.to_datetime(df['time'], format='%H:%M:%S').dt.hour
            
            # Group the data by 'day' and 'time' (hour) and calculate the average HR
            avg_hr_df = df.groupby(['day', 'time'])['HR'].mean().reset_index()
            
            # Round the HR values to the nearest 0.5 increment
            avg_hr_df['HR'] = avg_hr_df['HR'].apply(lambda x: round(x * 2) / 2)
            
            # Rename columns to match the requested format
            avg_hr_df.rename(columns={'HR': 'AVG HR', 'time': 'Time', 'day': 'Day'}, inplace=True)
            
            # Save the resulting DataFrame to an Excel file in the HR folder
            output_file_path = os.path.join(output_dir, f"{user_dir}.xlsx")
            avg_hr_df.to_excel(output_file_path, index=False)

print("Processing complete. Files saved in the 'HR' folder on your desktop.")