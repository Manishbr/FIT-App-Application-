import os
import pandas as pd

# Define the paths
main_dir = os.path.expanduser("~/Desktop/DataPaper")
output_dir = os.path.expanduser("~/Desktop/SleepData")

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Process each user's sleep.csv file
for user_num in range(1, 23):
    user_dir = f"user_{user_num}"
    user_path = os.path.join(main_dir, user_dir)

    if os.path.isdir(user_path):
        sleep_file = os.path.join(user_path, "sleep.csv")

        if os.path.isfile(sleep_file):
            # Load the sleep.csv file
            df = pd.read_csv(sleep_file)

            # Extract the desired columns based on the correct column names
            extracted_df = df[['In Bed Time', 'Efficiency', 'Total Minutes in Bed', 'Number of Awakenings']].copy()

            # Round 'Efficiency' to the nearest whole number
            extracted_df['Efficiency'] = df['Efficiency'].round()

            # Insert the 'Day' column next to 'In Bed Time'
            extracted_df.insert(1, 'Day', df['In Bed Date'].apply(lambda x: 2 if x == 1 else 1))

            # Save the extracted data to a new CSV file in the SleepData folder
            output_file_name = f"sleep_data_{user_num}.csv"
            output_file_path = os.path.join(output_dir, output_file_name)
            extracted_df.to_csv(output_file_path, index=False)

print("Sleep data has been extracted and saved in the 'SleepData' folder on your desktop.")