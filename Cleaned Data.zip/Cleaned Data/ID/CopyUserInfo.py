import os
import shutil

# Define the paths
main_dir = os.path.expanduser("~/Desktop/DataPaper")
output_dir = os.path.expanduser("~/Desktop/ID")

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Process each user's user_info.csv file
for user_num in range(1, 23):
    user_dir = f"user_{user_num}"
    user_path = os.path.join(main_dir, user_dir)
    
    if os.path.isdir(user_path):
        user_info_file = os.path.join(user_path, "user_info.csv")
        
        if os.path.isfile(user_info_file):
            # Define the new file name
            new_file_name = f"user_info_{user_num}.csv"
            new_file_path = os.path.join(output_dir, new_file_name)
            
            # Copy and rename the file to the ID folder
            shutil.copy(user_info_file, new_file_path)

print("User info files have been copied and renamed in the 'ID' folder on your desktop.")