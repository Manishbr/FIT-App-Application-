import os
import pandas as pd

# Define the paths
main_dir = os.path.expanduser("~/Desktop/DataPaper")
output_dir = os.path.expanduser("~/Desktop/ActivityScore")

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Scoring system and activity descriptions
scoring_system = {
    1: 50,  # Sleeping
    2: 25,  # Laying Down
    3: -5,  # Sitting
    4: 20,  # Light Movement
    5: 30,  # Medium Movement
    6: -20,  # Heavy Movement
    7: 20,  # Eating
    8: -20,  # Small Screen Usage
    9: -10,  # Large Screen Usage
    10: -5,  # Caffeinated Drink Consumption
    11: -50,  # Smoking
    12: -35  # Alcohol Consumption
}

activity_descriptions = {
    1: "Sleeping",
    2: "Laying Down",
    3: "Sitting",
    4: "Light Movement",
    5: "Medium Movement",
    6: "Heavy Movement",
    7: "Eating",
    8: "Small Screen Usage",
    9: "Large Screen Usage",
    10: "Caffeinated Drink Consumption",
    11: "Smoking",
    12: "Alcohol Consumption"
}


# Function to calculate duration and multiplier
def calculate_duration_and_multiplier(row):
    try:
        duration_in_minutes = (pd.to_datetime(row['End']) - pd.to_datetime(row['Start'])).seconds / 60
        if duration_in_minutes <= 15:
            multiplier = 1
        else:
            multiplier = 1 + ((duration_in_minutes - 1) // 15) * 0.25
        return duration_in_minutes, multiplier
    except:
        return None, None


# Process each user's Activity.csv file
for user_num in range(1, 23):
    user_dir = f"user_{user_num}"
    user_path = os.path.join(main_dir, user_dir)

    if os.path.isdir(user_path):
        actigraph_file = os.path.join(user_path, "Activity.csv")

        if os.path.isfile(actigraph_file):
            # Load the Activity.csv file
            df = pd.read_csv(actigraph_file)

            # Add activity descriptions
            df['Activity Description'] = df['Activity'].map(activity_descriptions)

            # Add the scoring column
            df['Scoring'] = df['Activity'].map(scoring_system)

            # Apply the function to calculate new columns
            df[['Duration (mins)', 'Multiplier']] = df.apply(calculate_duration_and_multiplier, axis=1,
                                                             result_type='expand')

            # Remove rows where Duration or Multiplier is None
            df.dropna(subset=['Duration (mins)', 'Multiplier'], inplace=True)

            # Calculate the score with multiplier
            df['Base Score (50 to -50)'] = df['Scoring']
            df['Total Score'] = df['Base Score (50 to -50)'] * df['Multiplier']

            # Create columns for Recovery and Training/Health Damage
            df['Recovery'] = df['Total Score'].apply(lambda x: x if x > 0 else 0)
            df['Training/Health Damage'] = df['Total Score'].apply(lambda x: x if x < 0 else 0)

            # Add index column with numbering
            df.insert(0, 'Index', range(1, len(df) + 1))

            # Reorder columns to move Total Score to the rightmost side
            df = df[['Index', 'Activity', 'Scoring', 'Activity Description', 'Start', 'End', 'Day',
                     'Duration (mins)', 'Multiplier', 'Base Score (50 to -50)',
                     'Recovery', 'Training/Health Damage', 'Total Score']]

            # Calculate the totals for each day separately
            totals_by_day = df.groupby('Day').agg({
                'Total Score': 'sum',
                'Recovery': 'sum',
                'Training/Health Damage': 'sum'
            }).reset_index()

            # Calculate efficiency for each day
            totals_by_day['Efficiency'] = ((totals_by_day['Recovery'] /
                                            (totals_by_day['Recovery'] - totals_by_day[
                                                'Training/Health Damage'])) * 100).fillna(0).round()

            # Append the totals and efficiency for each day at the bottom using pd.concat
            totals = []
            for index, row in totals_by_day.iterrows():
                totals.append(pd.DataFrame({
                    'Index': [f"Day {int(row['Day'])} Total", f"Day {int(row['Day'])} Efficiency"],
                    'Total Score': [row['Total Score'], row['Efficiency']],
                    'Recovery': [row['Recovery'], ''],
                    'Training/Health Damage': [row['Training/Health Damage'], ''],
                    'Multiplier': ['', ''],
                    'Activity': ['', ''],
                    'Scoring': ['', ''],
                    'Activity Description': ['', ''],
                    'Duration (mins)': ['', ''],
                    'Base Score (50 to -50)': ['', '']
                }))

            # Concatenate the totals to the DataFrame
            df = pd.concat([df] + totals, ignore_index=True)

            # Save the result to a new Excel file in the ActivityScore folder
            output_file_path = os.path.join(output_dir, f"{user_dir}.xlsx")
            df.to_excel(output_file_path, index=False)

print("Processing complete. Files saved in the 'ActivityScore' folder on your desktop.")