import os
import pandas as pd
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, Alignment

# Define the paths
main_dir = os.path.expanduser("~/Desktop/DataPaper")
output_dir = os.path.expanduser("~/Desktop/Score+")

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)


# Scoring functions
def score_meq(value):
    if value <= 41:
        return -5 * ((41 - value) // 5)
    elif 42 <= value <= 58:
        return 0
    else:
        return 5 * ((value - 59) // 5) + 5


def score_psqi(value):
    if value == 0:
        return 50
    elif value == 1:
        return 45
    elif value == 2:
        return 40
    elif value == 3:
        return 35
    elif value == 4:
        return 30
    elif value == 5:
        return 25
    elif value == 6:
        return 0
    elif value == 7:
        return -5
    elif value == 8:
        return -10
    elif value == 9:
        return -15
    elif value == 10:
        return -20
    else:
        return -25


def score_dsi(value):
    if value <= 100:
        return value // 2
    elif 101 <= value <= 200:
        return 0
    else:
        return -((value - 200) // 2)


# Process each user's questionnaire.csv file
for user_num in range(1, 23):
    user_dir = f"user_{user_num}"
    user_path = os.path.join(main_dir, user_dir)

    if os.path.isdir(user_path):
        questionnaire_file = os.path.join(user_path, "questionnaire.csv")

        if os.path.isfile(questionnaire_file):
            # Load the questionnaire.csv file
            df = pd.read_csv(questionnaire_file)

            # Extract the relevant columns
            df_relevant = df[['MEQ', 'Pittsburgh', 'Daily_stress']].copy()

            # Apply the scoring functions
            df_relevant['MEQ Score'] = df_relevant['MEQ'].apply(score_meq)
            df_relevant['PSQI Score'] = df_relevant['Pittsburgh'].apply(score_psqi)
            df_relevant['DSI Score'] = df_relevant['Daily_stress'].apply(score_dsi)

            # Calculate the efficiencies
            df_relevant['MEQ Efficiency'] = df_relevant['MEQ Score'].apply(lambda x: (x / 50) * 100)
            df_relevant['PSQI Efficiency'] = df_relevant['PSQI Score'].apply(lambda x: (x / 50) * 100)
            df_relevant['DSI Efficiency'] = df_relevant['DSI Score'].apply(lambda x: (x / 50) * 100)
            df_relevant['Total Score'] = df_relevant['MEQ Score'] + df_relevant['PSQI Score'] + df_relevant['DSI Score']
            df_relevant['Total Efficiency + (%)'] = df_relevant[
                ['MEQ Efficiency', 'PSQI Efficiency', 'DSI Efficiency']].mean(axis=1).round()

            # Create a new workbook and select the active worksheet
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Questionnaire Scoring"

            # Add headers with ranges in merged cells above the categories
            ws.merge_cells('A1:C1')
            ws.merge_cells('D1:F1')
            ws.merge_cells('G1:I1')
            ws.merge_cells('J1:K1')

            ws['A1'] = "MEQ (0-41: -50 to 0, 42-58: 0, 59+: 0 to +50)"
            ws['D1'] = "Pittsburgh (0-10: +50 to -25)"
            ws['G1'] = "Daily_stress (0-100: 0 to +50, 101-200: 0, 201-406: 0 to -50)"
            ws['J1'] = "Total Score and Efficiency"

            # Add headers for the columns below the merged cells
            headers = [
                "MEQ", "MEQ Score", "MEQ Efficiency (%)",
                "Pittsburgh", "PSQI Score", "PSQI Efficiency (%)",
                "Daily_stress", "DSI Score", "DSI Efficiency (%)",
                "Total Score", "Total Efficiency + (%)"
            ]
            ws.append(headers)

            # Add data to the worksheet
            for _, row in df_relevant.iterrows():
                ws.append([
                    row['MEQ'], row['MEQ Score'], row['MEQ Efficiency'],
                    row['Pittsburgh'], row['PSQI Score'], row['PSQI Efficiency'],
                    row['Daily_stress'], row['DSI Score'], row['DSI Efficiency'],
                    row['Total Score'], row['Total Efficiency + (%)']
                ])

            # Apply formatting to the headers and merged cells
            for cell in ws[1]:
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal="center")

            for cell in ws[2]:
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal="center")

            # Save the workbook
            output_file_name = f"user_{user_num}.xlsx"
            output_file_path = os.path.join(output_dir, output_file_name)
            wb.save(output_file_path)

print("Processing complete. Files saved in the 'Score+' folder on your desktop.")